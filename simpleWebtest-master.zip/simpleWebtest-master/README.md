simpleWebtest :smile:
=============

用selenium做的一个简单的web测试框架。a simple web test framework which using selenium.

My Blogs：(Chinese Only)

我的博客：（每周可能更新一篇左右）

selenium从入门到应用 - 1，环境准备（Java+TestNG+Maven+Selenium） 
http://www.cnblogs.com/sdet/p/3633623.html

selenium从入门到应用 - 2，简单线性脚本的编写
http://www.cnblogs.com/sdet/p/3633639.html

selenium从入门到应用 - 3，进阶线性脚本的编写

selenium从入门到应用 - 4，页面对象设计模式的实现
http://www.cnblogs.com/sdet/p/3648530.html

selenium从入门到应用 - 5，页面对象设计模式下的页面模块
http://www.cnblogs.com/sdet/p/3649096.html

selenium从入门到应用 - 6，EventFiringWebDriver和监听器
http://www.cnblogs.com/sdet/p/3648993.html

selenium从入门到应用 - 7，数据驱动的selenium测试脚本

Maven 小技巧之 自动更新你的jar包
http://www.cnblogs.com/sdet/p/3646235.html